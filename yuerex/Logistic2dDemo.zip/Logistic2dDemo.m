
%% Image Encryption Demo - Encryption and Decryption
clear all
close all
clc

%% 1. Load plaintext images
% Image 1
I = imread('cameraman.tif');

%% 2. Encryption
[CI,K] = Logistic2D_ImageCipher(I,'encryption');

%% 3. Decryption
DI = Logistic2D_ImageCipher(CI,'decryption',K);

%% 4. Analaysis
% Histogram
figure,subplot(221),imshow(I,[]),subplot(222),imshow(CI,[])
subplot(223),imhist(I),subplot(224),imhist(CI)

%%=========================================================================
% Demo - NPCR
clear all
close all
clc

%% 1. Load plaintext images
% Image 1
I = imread('cameraman.tif');
% Image 2
J = I;
J(1) = 0;

%% 2. Encryption using same key
[CI,K] = Logistic2D_ImageCipher(I,'encryption');
CJ = Logistic2D_ImageCipher(J,'encryption',K);

% NPCR
figure,subplot(231),imshow(I,[]),title('P_1'),subplot(232),imshow(J,[]),title('P_2'),subplot(233),imshow(imabsdiff(I,J),[]),title('|P_1-P_2|')
subplot(234),imshow(CI,[]),title('C_1'),subplot(235),imshow(CJ,[]),title('C_2'),subplot(236),imshow(imabsdiff(CI,CJ),[]),title('|C_1-C_2|')

%%
%%=========================================================================
% Demo - Key Sensitivity
clear all
close all
clc

%% 1. Load plaintext images
% Image 1
I = imread('cameraman.tif');

%% 2. Encryption
[CI,K] = Logistic2D_ImageCipher(I,'encryption');

%% 3. Generate two similar keys
K2 = K;
pos = randi(256);
K2(pos) = 1-K(pos);

K3 = K;
pos = randi(256);
K3(pos) = 1-K(pos);

%% 4. Encryption Sensitivity
CI2 = Logistic2D_ImageCipher(I,'encryption',K2);
CI3 = Logistic2D_ImageCipher(I,'encryption',K3);

%% 5. Decryption Sensitivity
DI2 = Logistic2D_ImageCipher(CI,'encryption',K2);
DI3 = Logistic2D_ImageCipher(CI,'encryption',K3);

figure,subplot(231),imshow(CI2,[]),title('C_2'),subplot(232),imshow(CI3,[]),title('C_3'),subplot(233),imshow(imabsdiff(CI2,CI3),[]),title('|C_3-C_2|')
subplot(234),imshow(DI2,[]),title('D_3'),subplot(235),imshow(DI3,[]),title('D_2'),subplot(236),imshow(imabsdiff(DI2,DI3),[]),title('|D_3-D_2|')